from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError

from apps.devices.models import Bracelet, BraceletAssignment, BraceletStatus


class BraceletAssignmentService:
    @staticmethod
    @transaction.atomic
    def assign(bracelet: Bracelet, person, assigned_by, reason: str = ""):
        if bracelet.status == BraceletStatus.DEACTIVATED:
            raise ValidationError("Cannot assign a deactivated bracelet.")
        # Close existing assignment
        BraceletAssignment.objects.filter(
            bracelet=bracelet, unassigned_at__isnull=True
        ).update(unassigned_at=timezone.now())
        # Unassign person from other bracelets
        for other in Bracelet.objects.filter(current_person=person).exclude(pk=bracelet.pk):
            BraceletAssignment.objects.filter(
                bracelet=other, unassigned_at__isnull=True
            ).update(unassigned_at=timezone.now())
            other.current_person = None
            other.status = BraceletStatus.UNASSIGNED
            other.save(update_fields=["current_person", "status", "updated_at"])

        assignment = BraceletAssignment.objects.create(
            bracelet=bracelet,
            person=person,
            organization=bracelet.organization or person.organization,
            assigned_by=assigned_by,
            reason=reason,
        )
        bracelet.current_person = person
        if person.organization_id and not bracelet.organization_id:
            bracelet.organization = person.organization
        if person.owner_user_id and not bracelet.owner_user_id:
            bracelet.owner_user = person.owner_user
        bracelet.status = BraceletStatus.IN_USE
        if not bracelet.activated_at:
            bracelet.activated_at = timezone.now()
            if bracelet.status == BraceletStatus.IN_USE:
                pass
        bracelet.save()
        return assignment

    @staticmethod
    @transaction.atomic
    def unassign(bracelet: Bracelet, reason: str = ""):
        BraceletAssignment.objects.filter(
            bracelet=bracelet, unassigned_at__isnull=True
        ).update(unassigned_at=timezone.now())
        bracelet.current_person = None
        bracelet.status = BraceletStatus.UNASSIGNED
        bracelet.save(update_fields=["current_person", "status", "updated_at"])
        return bracelet

    @staticmethod
    def activate(bracelet: Bracelet):
        # Reactivate from DEACTIVATED / inventory / unassigned → ACTIVATED (unassigned until assign).
        bracelet.current_person = None
        bracelet.status = BraceletStatus.ACTIVATED
        bracelet.activated_at = timezone.now()
        bracelet.save(
            update_fields=["current_person", "status", "activated_at", "updated_at"]
        )
        return bracelet

    @staticmethod
    def deactivate(bracelet: Bracelet):
        BraceletAssignment.objects.filter(
            bracelet=bracelet, unassigned_at__isnull=True
        ).update(unassigned_at=timezone.now())
        bracelet.current_person = None
        bracelet.status = BraceletStatus.DEACTIVATED
        bracelet.save(update_fields=["current_person", "status", "updated_at"])
        return bracelet
