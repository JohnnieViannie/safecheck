from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.mail import send_mail
from django.utils import timezone
from rest_framework import permissions, status, viewsets
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.response import Response

from apps.audit.services import AuditService
from apps.organizations.permissions import ADMIN_ROLES, get_membership, user_org_ids

from .models import Invitation, Organization, OrganizationMembership
from .serializers import (
    InvitationAcceptSerializer,
    InvitationCreateSerializer,
    InvitationSerializer,
    MembershipSerializer,
    OrganizationCreateSerializer,
    OrganizationSerializer,
)
from .services import OrganizationService

User = get_user_model()


class OrganizationViewSet(viewsets.ModelViewSet):
    serializer_class = OrganizationSerializer
    search_fields = ["name", "slug", "email"]
    ordering_fields = ["name", "created_at"]

    def get_queryset(self):
        user = self.request.user
        if user.is_platform_admin:
            return Organization.objects.all()
        return Organization.objects.filter(id__in=user_org_ids(user))

    def create(self, request, *args, **kwargs):
        ser = OrganizationCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        org = OrganizationService.create_organization(owner=request.user, **ser.validated_data)
        AuditService.log(
            actor=request.user,
            action="organization.created",
            object_type="Organization",
            object_id=str(org.id),
            metadata={"name": org.name},
            request=request,
        )
        return Response(OrganizationSerializer(org).data, status=201)

    def perform_update(self, serializer):
        org = self.get_object()
        if not self.request.user.is_platform_admin:
            m = get_membership(self.request.user, org.id)
            if not m or m.role not in ADMIN_ROLES:
                from rest_framework.exceptions import PermissionDenied

                raise PermissionDenied("Admin role required.")
        serializer.save()
        AuditService.log(
            actor=self.request.user,
            action="organization.updated",
            object_type="Organization",
            object_id=str(org.id),
            request=self.request,
        )

    def destroy(self, request, *args, **kwargs):
        if not request.user.is_platform_admin:
            return Response({"error": "Only platform admins can delete organizations."}, status=403)
        org = self.get_object()
        org_id = str(org.id)
        name = org.name
        response = super().destroy(request, *args, **kwargs)
        AuditService.log(
            actor=request.user,
            action="organization.deleted",
            object_type="Organization",
            object_id=org_id,
            metadata={"name": name},
            request=request,
        )
        return response

    @action(detail=True, methods=["post"])
    def deactivate(self, request, pk=None):
        if not request.user.is_platform_admin:
            return Response({"error": "Only platform admins can deactivate organizations."}, status=403)
        org = self.get_object()
        org.is_active = False
        org.save(update_fields=["is_active", "updated_at"])
        AuditService.log(
            actor=request.user,
            action="organization.deactivated",
            object_type="Organization",
            object_id=str(org.id),
            organization=org,
            request=request,
        )
        return Response(OrganizationSerializer(org).data)

    @action(detail=True, methods=["post"])
    def activate(self, request, pk=None):
        if not request.user.is_platform_admin:
            return Response({"error": "Only platform admins can activate organizations."}, status=403)
        org = self.get_object()
        org.is_active = True
        org.save(update_fields=["is_active", "updated_at"])
        AuditService.log(
            actor=request.user,
            action="organization.activated",
            object_type="Organization",
            object_id=str(org.id),
            organization=org,
            request=request,
        )
        return Response(OrganizationSerializer(org).data)

    @action(detail=True, methods=["get", "post"])
    def members(self, request, pk=None):
        org = self.get_object()
        if request.method == "GET":
            qs = org.memberships.select_related("user").filter(is_active=True)
            return Response(MembershipSerializer(qs, many=True).data)
        if not request.user.is_platform_admin:
            m = get_membership(request.user, org.id)
            if not m or m.role not in ADMIN_ROLES:
                return Response({"error": "Forbidden"}, status=403)
        role = request.data.get("role", "STAFF")
        email = request.data.get("email")
        if not email:
            return Response({"error": "email required"}, status=400)
        try:
            user = User.objects.get(email__iexact=email)
        except User.DoesNotExist:
            return Response({"error": "User not found. Invite them instead."}, status=404)
        membership, created = OrganizationMembership.objects.update_or_create(
            organization=org,
            user=user,
            defaults={"role": role, "is_active": True},
        )
        AuditService.log(
            actor=request.user,
            action="membership.created" if created else "membership.updated",
            object_type="OrganizationMembership",
            object_id=str(membership.id),
            organization=org,
            request=request,
        )
        return Response(MembershipSerializer(membership).data, status=201 if created else 200)

    @action(detail=True, methods=["get", "post"])
    def invitations(self, request, pk=None):
        org = self.get_object()
        if not request.user.is_platform_admin:
            m = get_membership(request.user, org.id)
            if not m or m.role not in ADMIN_ROLES:
                return Response({"error": "Forbidden"}, status=403)
        if request.method == "GET":
            qs = org.invitations.all()[:50]
            return Response(InvitationSerializer(qs, many=True).data)
        ser = InvitationCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        inv = Invitation.create_invitation(
            organization=org,
            email=ser.validated_data["email"],
            role=ser.validated_data["role"],
            invited_by=request.user,
        )
        link = f"{settings.FRONTEND_URL}/accept-invite?token={inv.token}"
        send_mail(
            subject=f"Invitation to join {org.name} on SafeBangle",
            message=f"You have been invited to {org.name} as {inv.role}.\n\nAccept: {link}",
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[inv.email],
            fail_silently=True,
        )
        AuditService.log(
            actor=request.user,
            action="invitation.created",
            object_type="Invitation",
            object_id=str(inv.id),
            organization=org,
            metadata={"email": inv.email, "role": inv.role},
            request=request,
        )
        return Response(InvitationSerializer(inv).data, status=201)


@api_view(["POST"])
@permission_classes([permissions.IsAuthenticated])
def accept_invitation(request):
    ser = InvitationAcceptSerializer(data=request.data)
    ser.is_valid(raise_exception=True)
    try:
        inv = Invitation.objects.select_related("organization").get(
            token=ser.validated_data["token"]
        )
    except Invitation.DoesNotExist:
        return Response({"error": "Invalid invitation."}, status=400)
    if not inv.is_valid:
        return Response({"error": "Invitation expired or already used."}, status=400)
    if request.user.email.lower() != inv.email.lower():
        return Response(
            {"error": "Invitation email does not match your account."}, status=403
        )
    membership, _ = OrganizationMembership.objects.update_or_create(
        organization=inv.organization,
        user=request.user,
        defaults={"role": inv.role, "is_active": True},
    )
    inv.accepted_at = timezone.now()
    inv.save(update_fields=["accepted_at"])
    AuditService.log(
        actor=request.user,
        action="invitation.accepted",
        object_type="Invitation",
        object_id=str(inv.id),
        organization=inv.organization,
        request=request,
    )
    return Response(
        {
            "membership": MembershipSerializer(membership).data,
            "organization": OrganizationSerializer(inv.organization).data,
        }
    )


@api_view(["POST"])
@permission_classes([permissions.IsAuthenticated])
def revoke_invitation(request, invitation_id):
    try:
        inv = Invitation.objects.select_related("organization").get(id=invitation_id)
    except Invitation.DoesNotExist:
        return Response({"error": "Not found"}, status=404)
    if not request.user.is_platform_admin:
        m = get_membership(request.user, inv.organization_id)
        if not m or m.role not in ADMIN_ROLES:
            return Response({"error": "Forbidden"}, status=403)
    inv.revoked_at = timezone.now()
    inv.save(update_fields=["revoked_at"])
    return Response({"message": "Invitation revoked."})
