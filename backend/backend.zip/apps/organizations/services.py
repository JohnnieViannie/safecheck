from django.utils.text import slugify

from apps.organizations.models import MembershipRole, Organization, OrganizationMembership


class OrganizationService:
    @staticmethod
    def _unique_slug(name: str) -> str:
        base = slugify(name) or "org"
        slug = base
        i = 1
        while Organization.objects.filter(slug=slug).exists():
            slug = f"{base}-{i}"
            i += 1
        return slug

    @classmethod
    def create_organization(cls, name: str, owner, **extra) -> Organization:
        org = Organization.objects.create(
            name=name, slug=cls._unique_slug(name), **extra
        )
        OrganizationMembership.objects.create(
            organization=org,
            user=owner,
            role=MembershipRole.OWNER,
        )
        return org
