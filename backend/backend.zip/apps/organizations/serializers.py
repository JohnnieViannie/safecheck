from django.contrib.auth import get_user_model
from rest_framework import serializers

from .models import Invitation, MembershipRole, Organization, OrganizationMembership

User = get_user_model()


class OrganizationSerializer(serializers.ModelSerializer):
    member_count = serializers.SerializerMethodField()

    class Meta:
        model = Organization
        fields = [
            "id",
            "name",
            "slug",
            "description",
            "email",
            "phone",
            "address",
            "is_active",
            "member_count",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["id", "slug", "created_at", "updated_at", "member_count"]

    def get_member_count(self, obj):
        return obj.memberships.filter(is_active=True).count()


class OrganizationCreateSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=255)
    description = serializers.CharField(required=False, allow_blank=True, default="")
    email = serializers.EmailField(required=False, allow_blank=True, default="")
    phone = serializers.CharField(required=False, allow_blank=True, default="")
    address = serializers.CharField(required=False, allow_blank=True, default="")


class MembershipBriefSerializer(serializers.ModelSerializer):
    organization_id = serializers.UUIDField(source="organization.id")
    organization_name = serializers.CharField(source="organization.name")

    class Meta:
        model = OrganizationMembership
        fields = ["id", "organization_id", "organization_name", "role", "is_active"]


class MembershipSerializer(serializers.ModelSerializer):
    user_email = serializers.EmailField(source="user.email", read_only=True)
    user_name = serializers.CharField(source="user.full_name", read_only=True)
    user_id = serializers.UUIDField(source="user.id", read_only=True)

    class Meta:
        model = OrganizationMembership
        fields = [
            "id",
            "organization",
            "user_id",
            "user_email",
            "user_name",
            "role",
            "is_active",
            "created_at",
        ]
        read_only_fields = ["id", "organization", "created_at"]


class InvitationSerializer(serializers.ModelSerializer):
    organization_name = serializers.CharField(source="organization.name", read_only=True)
    is_valid = serializers.BooleanField(read_only=True)

    class Meta:
        model = Invitation
        fields = [
            "id",
            "organization",
            "organization_name",
            "email",
            "role",
            "created_at",
            "expires_at",
            "accepted_at",
            "revoked_at",
            "is_valid",
        ]
        read_only_fields = [
            "id",
            "organization",
            "created_at",
            "expires_at",
            "accepted_at",
            "revoked_at",
            "is_valid",
        ]


class InvitationCreateSerializer(serializers.Serializer):
    email = serializers.EmailField()
    role = serializers.ChoiceField(
        choices=MembershipRole.choices, default=MembershipRole.STAFF
    )


class InvitationAcceptSerializer(serializers.Serializer):
    token = serializers.CharField()
