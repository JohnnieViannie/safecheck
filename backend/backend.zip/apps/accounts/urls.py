from django.urls import include, path
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenRefreshView

from .views import (
    UserViewSet,
    change_password,
    detect_country,
    forgot_password,
    login,
    me,
    register,
    resend_verification,
    reset_password,
    verify_email,
)

router = DefaultRouter()
router.register("users", UserViewSet, basename="users")

urlpatterns = [
    path("register/", register),
    path("login/", login),
    path("refresh/", TokenRefreshView.as_view()),
    path("me/", me),
    path("geo/", detect_country),
    path("verify-email/", verify_email),
    path("resend-verification/", resend_verification),
    path("forgot-password/", forgot_password),
    path("reset-password/", reset_password),
    path("change-password/", change_password),
    path("", include(router.urls)),
]
