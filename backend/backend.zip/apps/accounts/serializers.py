from datetime import date

from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from rest_framework import serializers

User = get_user_model()

SEX_CHOICES = ["female", "male", "other", "prefer_not"]


class UserSerializer(serializers.ModelSerializer):
    full_name = serializers.CharField(read_only=True)
    age = serializers.IntegerField(read_only=True, allow_null=True)
    memberships = serializers.SerializerMethodField()
    bracelet_count = serializers.SerializerMethodField()
    person_count = serializers.SerializerMethodField()
    has_app_profile = serializers.SerializerMethodField()
    has_watch = serializers.SerializerMethodField()
    sources = serializers.SerializerMethodField()
    status_label = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            "id",
            "email",
            "first_name",
            "last_name",
            "full_name",
            "phone",
            "country_code",
            "sex",
            "date_of_birth",
            "age",
            "is_active",
            "is_muted",
            "is_platform_admin",
            "email_verified",
            "account_type",
            "memberships",
            "bracelet_count",
            "person_count",
            "has_app_profile",
            "has_watch",
            "sources",
            "status_label",
            "created_at",
            "updated_at",
        ]
        read_only_fields = [
            "id",
            "full_name",
            "age",
            "memberships",
            "bracelet_count",
            "person_count",
            "has_app_profile",
            "has_watch",
            "sources",
            "status_label",
            "created_at",
            "updated_at",
            "is_platform_admin",
            "email_verified",
            "account_type",
        ]

    def get_memberships(self, obj):
        from apps.organizations.serializers import MembershipBriefSerializer

        qs = obj.memberships.select_related("organization").filter(is_active=True)
        return MembershipBriefSerializer(qs, many=True).data

    def get_bracelet_count(self, obj):
        if getattr(obj, "_bracelet_count", None) is not None:
            return obj._bracelet_count
        return obj.bracelets.count()

    def get_person_count(self, obj):
        owned = getattr(obj, "_owned_people", None)
        linked = getattr(obj, "_linked_people", None)
        if owned is not None and linked is not None:
            return int(owned) + int(linked)
        return obj.owned_people.count() + obj.person_profiles.count()

    def get_has_app_profile(self, obj):
        flagged = getattr(obj, "_has_app_profile", None)
        if flagged is not None:
            return bool(flagged)
        from apps.safety.models import SafetyProfile

        return SafetyProfile.objects.filter(user_id=obj.id).exists()

    def get_has_watch(self, obj):
        count = self.get_bracelet_count(obj)
        return bool(count and count > 0)

    def get_sources(self, obj):
        labels = []
        if self.get_has_app_profile(obj) or obj.account_type:
            labels.append("app")
        if self.get_has_watch(obj):
            labels.append("watch")
        if obj.account_type == "organization" or obj.memberships.filter(is_active=True).exists():
            if "org" not in labels:
                labels.append("org")
        return labels or ["app"]

    def get_status_label(self, obj):
        if not obj.is_active:
            return "blocked"
        if obj.is_muted:
            return "muted"
        return "active"


class AdminUserUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = [
            "first_name",
            "last_name",
            "phone",
            "country_code",
            "sex",
            "date_of_birth",
            "is_active",
            "is_muted",
        ]


class RegisterSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True, min_length=8)
    first_name = serializers.CharField(required=False, allow_blank=True, default="")
    last_name = serializers.CharField(required=False, allow_blank=True, default="")
    phone = serializers.CharField(required=False, allow_blank=True, default="")
    country_code = serializers.CharField(required=False, allow_blank=True, default="", max_length=2)
    sex = serializers.ChoiceField(choices=SEX_CHOICES)
    date_of_birth = serializers.DateField()
    account_type = serializers.ChoiceField(
        choices=["individual", "organization"], default="individual"
    )
    organization_name = serializers.CharField(required=False, allow_blank=True)

    def validate_email(self, value):
        if User.objects.filter(email__iexact=value).exists():
            raise serializers.ValidationError("An account with this email already exists.")
        return value.lower()

    def validate_password(self, value):
        validate_password(value)
        return value

    def validate_date_of_birth(self, value: date):
        today = date.today()
        if value > today:
            raise serializers.ValidationError("Date of birth cannot be in the future.")
        age = today.year - value.year - (
            (today.month, today.day) < (value.month, value.day)
        )
        if age < 13:
            raise serializers.ValidationError("You must be at least 13 years old.")
        if age > 120:
            raise serializers.ValidationError("Please enter a valid date of birth.")
        return value

    def validate_country_code(self, value):
        return (value or "").upper()

    def validate(self, attrs):
        if attrs.get("account_type") == "organization" and not attrs.get(
            "organization_name"
        ):
            raise serializers.ValidationError(
                {"organization_name": "Organization name is required."}
            )
        return attrs


class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)


class ProfileUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["first_name", "last_name", "phone", "country_code", "sex", "date_of_birth"]


class PasswordResetRequestSerializer(serializers.Serializer):
    email = serializers.EmailField()


class PasswordResetConfirmSerializer(serializers.Serializer):
    email = serializers.EmailField()
    code = serializers.CharField(min_length=6, max_length=6)
    password = serializers.CharField(min_length=6, required=False)
    newPassword = serializers.CharField(min_length=6, required=False)
    verificationId = serializers.CharField(required=False, allow_blank=True)

    def validate(self, attrs):
        password = attrs.get("password") or attrs.get("newPassword")
        if not password:
            raise serializers.ValidationError(
                {"password": "password or newPassword is required."}
            )
        validate_password(password)
        attrs["password"] = password
        return attrs

    def validate_code(self, value):
        if not value.isdigit():
            raise serializers.ValidationError("Code must be 6 digits.")
        return value


class ChangePasswordSerializer(serializers.Serializer):
    current_password = serializers.CharField()
    new_password = serializers.CharField(min_length=8)

    def validate_new_password(self, value):
        validate_password(value)
        return value


class EmailVerifySerializer(serializers.Serializer):
    email = serializers.EmailField()
    code = serializers.CharField(min_length=6, max_length=6)

    def validate_code(self, value):
        if not value.isdigit():
            raise serializers.ValidationError("Code must be 6 digits.")
        return value


class ResendCodeSerializer(serializers.Serializer):
    email = serializers.EmailField()
