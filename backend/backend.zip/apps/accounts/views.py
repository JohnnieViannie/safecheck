from django.contrib.auth import authenticate, get_user_model
from django.utils import timezone
from rest_framework import permissions, status, viewsets
from rest_framework.decorators import api_view, permission_classes, throttle_classes
from rest_framework.response import Response
from rest_framework.throttling import AnonRateThrottle
from rest_framework_simplejwt.tokens import RefreshToken

from apps.audit.services import AuditService
from apps.organizations.services import OrganizationService

from .emails import send_branded_code_email
from .geo import dial_codes_payload, dial_for_iso
from .models import EmailVerificationToken, PasswordResetToken
from .serializers import (
    AdminUserUpdateSerializer,
    ChangePasswordSerializer,
    EmailVerifySerializer,
    LoginSerializer,
    PasswordResetConfirmSerializer,
    PasswordResetRequestSerializer,
    ProfileUpdateSerializer,
    RegisterSerializer,
    ResendCodeSerializer,
    UserSerializer,
)
from apps.organizations.permissions import IsPlatformAdmin
from django.db.models import Count, Exists, OuterRef, Q
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated

User = get_user_model()


class AuthThrottle(AnonRateThrottle):
    scope = "auth"


def tokens_for_user(user):
    refresh = RefreshToken.for_user(user)
    return {"access": str(refresh.access_token), "refresh": str(refresh)}


def _send_code_email(*, email: str, code: str, purpose: str):
    try:
        send_branded_code_email(to_email=email, code=code, purpose=purpose)
    except Exception as exc:
        import logging

        from django.conf import settings

        logging.getLogger(__name__).exception("Failed to send %s email to %s", purpose, email)
        if settings.DEBUG:
            # Hosting SMTP may be down — print code in the server terminal so local
            # development can continue. Never returned in the API response.
            print(
                f"\n*** DEBUG {purpose} code for {email}: {code} ***\n",
                flush=True,
            )
            return
        raise RuntimeError(
            "We could not send the email right now. Check your inbox later or try again."
        ) from exc


def _client_ip(request) -> str:
    xff = request.META.get("HTTP_X_FORWARDED_FOR")
    if xff:
        return xff.split(",")[0].strip()
    return request.META.get("REMOTE_ADDR") or ""


@api_view(["GET"])
@permission_classes([permissions.AllowAny])
def detect_country(request):
    """Detect visitor country for phone dial-code autofill."""
    import logging

    import requests as http

    from .geo import COUNTRY_DIAL_CODES

    logger = logging.getLogger(__name__)
    iso = (
        request.headers.get("CF-IPCountry")
        or request.META.get("HTTP_CF_IPCOUNTRY")
        or request.headers.get("X-Country-Code")
        or ""
    ).upper()
    if iso in {"", "XX", "T1"}:
        iso = ""

    ip = _client_ip(request)
    if not iso and ip and ip not in {"127.0.0.1", "::1"}:
        try:
            resp = http.get(f"http://ip-api.com/json/{ip}?fields=status,countryCode", timeout=3)
            payload = resp.json()
            if payload.get("status") == "success":
                iso = (payload.get("countryCode") or "").upper()
        except Exception:
            logger.info("Geo lookup failed for %s", ip)

    if not iso:
        iso = "KE"  # default for SafeBangle primary market

    dial = dial_for_iso(iso) or "+254"
    name = next((n for c, n, _d in COUNTRY_DIAL_CODES if c == iso), iso)
    return Response(
        {
            "country_code": iso,
            "country_name": name,
            "dial_code": dial,
            "dial_codes": dial_codes_payload(),
        }
    )


@api_view(["POST"])
@permission_classes([permissions.AllowAny])
@throttle_classes([AuthThrottle])
def register(request):
    ser = RegisterSerializer(data=request.data)
    ser.is_valid(raise_exception=True)
    data = ser.validated_data
    user = User.objects.create_user(
        email=data["email"],
        password=data["password"],
        first_name=data.get("first_name", ""),
        last_name=data.get("last_name", ""),
        phone=data.get("phone", ""),
        country_code=data.get("country_code", ""),
        sex=data.get("sex", ""),
        date_of_birth=data.get("date_of_birth"),
        account_type=data.get("account_type", "individual"),
        email_verified=False,
    )
    if data.get("account_type") == "organization":
        org = OrganizationService.create_organization(
            name=data["organization_name"], owner=user
        )
        AuditService.log(
            actor=user,
            action="organization.created",
            object_type="Organization",
            object_id=str(org.id),
            metadata={"name": org.name},
            request=request,
        )

    verification = EmailVerificationToken.create_for_user(user)
    try:
        _send_code_email(
            email=user.email,
            code=verification.token,
            purpose="email verification",
        )
    except RuntimeError as exc:
        return Response({"error": str(exc)}, status=503)
    AuditService.log(
        actor=user,
        action="user.registered",
        object_type="User",
        object_id=str(user.id),
        request=request,
    )
    return Response(
        {
            "message": "Account created. Enter the 6-digit code sent to your email.",
            "email": user.email,
            "requires_verification": True,
        },
        status=status.HTTP_201_CREATED,
    )


@api_view(["POST"])
@permission_classes([permissions.AllowAny])
@throttle_classes([AuthThrottle])
def login(request):
    ser = LoginSerializer(data=request.data)
    ser.is_valid(raise_exception=True)
    email = ser.validated_data["email"].lower()
    user = authenticate(
        request,
        username=email,
        password=ser.validated_data["password"],
    )
    if not user:
        return Response({"error": "Invalid email or password."}, status=401)
    if not user.is_active:
        return Response({"error": "Account is disabled."}, status=403)
    if not user.email_verified and not user.is_platform_admin:
        verification = EmailVerificationToken.create_for_user(user)
        try:
            _send_code_email(
                email=user.email,
                code=verification.token,
                purpose="email verification",
            )
        except RuntimeError as exc:
            return Response({"error": str(exc), "requires_verification": True, "email": user.email}, status=503)
        return Response(
            {
                "error": "Email not verified. We sent a new code to your inbox.",
                "requires_verification": True,
                "email": user.email,
                "code_resent": True,
            },
            status=403,
        )
    AuditService.log(
        actor=user,
        action="user.login",
        object_type="User",
        object_id=str(user.id),
        request=request,
    )
    return Response({"user": UserSerializer(user).data, "tokens": tokens_for_user(user)})


@api_view(["GET", "PATCH"])
@permission_classes([permissions.IsAuthenticated])
def me(request):
    if request.method == "GET":
        return Response(UserSerializer(request.user).data)
    ser = ProfileUpdateSerializer(request.user, data=request.data, partial=True)
    ser.is_valid(raise_exception=True)
    ser.save()
    return Response(UserSerializer(request.user).data)


@api_view(["POST"])
@permission_classes([permissions.AllowAny])
@throttle_classes([AuthThrottle])
def verify_email(request):
    ser = EmailVerifySerializer(data=request.data)
    ser.is_valid(raise_exception=True)
    email = ser.validated_data["email"].lower()
    code = ser.validated_data["code"]
    try:
        user = User.objects.get(email__iexact=email)
    except User.DoesNotExist:
        return Response({"error": "Invalid email or code."}, status=400)

    token = (
        EmailVerificationToken.objects.filter(user=user, token=code, used_at__isnull=True)
        .order_by("-created_at")
        .first()
    )
    if not token or not token.is_valid:
        return Response({"error": "Invalid or expired verification code."}, status=400)

    token.used_at = timezone.now()
    token.save(update_fields=["used_at"])
    user.email_verified = True
    user.save(update_fields=["email_verified"])
    AuditService.log(
        actor=user,
        action="user.email_verified",
        object_type="User",
        object_id=str(user.id),
        request=request,
    )
    return Response(
        {
            "message": "Email verified. You can sign in now.",
            "user": UserSerializer(user).data,
            "tokens": tokens_for_user(user),
        }
    )


@api_view(["POST"])
@permission_classes([permissions.AllowAny])
@throttle_classes([AuthThrottle])
def resend_verification(request):
    ser = ResendCodeSerializer(data=request.data)
    ser.is_valid(raise_exception=True)
    email = ser.validated_data["email"].lower()
    try:
        user = User.objects.get(email__iexact=email)
    except User.DoesNotExist:
        return Response({"message": "If that email exists, a new code was sent."})
    if user.email_verified:
        return Response({"message": "Email is already verified. You can sign in."})
    verification = EmailVerificationToken.create_for_user(user)
    try:
        _send_code_email(
            email=user.email,
            code=verification.token,
            purpose="email verification",
        )
    except RuntimeError as exc:
        return Response({"error": str(exc)}, status=503)
    return Response({"message": "If that email exists, a new code was sent."})


@api_view(["POST"])
@permission_classes([permissions.AllowAny])
@throttle_classes([AuthThrottle])
def forgot_password(request):
    ser = PasswordResetRequestSerializer(data=request.data)
    ser.is_valid(raise_exception=True)
    email = ser.validated_data["email"].lower()
    try:
        user = User.objects.get(email__iexact=email)
    except User.DoesNotExist:
        return Response({"message": "If that email exists, a reset code was sent."})
    token = PasswordResetToken.create_for_user(user)
    try:
        _send_code_email(
            email=user.email,
            code=token.token,
            purpose="password reset",
        )
    except RuntimeError as exc:
        return Response({"error": str(exc)}, status=503)
    # Dual response: Blaces web + SafeCheck mobile (verificationId).
    return Response(
        {
            "message": "If that email exists, a reset code was sent.",
            "email": email,
            "verificationId": f"reset-{token.id.hex[:12]}",
        }
    )


@api_view(["POST"])
@permission_classes([permissions.AllowAny])
@throttle_classes([AuthThrottle])
def reset_password(request):
    ser = PasswordResetConfirmSerializer(data=request.data)
    ser.is_valid(raise_exception=True)
    email = ser.validated_data["email"].lower()
    code = ser.validated_data["code"]
    try:
        user = User.objects.get(email__iexact=email)
    except User.DoesNotExist:
        return Response({"error": "Invalid email or code."}, status=400)

    token = (
        PasswordResetToken.objects.filter(user=user, token=code, used_at__isnull=True)
        .order_by("-created_at")
        .first()
    )
    if not token or not token.is_valid:
        return Response({"error": "Invalid or expired reset code."}, status=400)

    token.used_at = timezone.now()
    token.save(update_fields=["used_at"])
    user.set_password(ser.validated_data["password"])
    user.save()
    AuditService.log(
        actor=user,
        action="user.password_reset",
        object_type="User",
        object_id=str(user.id),
        request=request,
    )

    # Mobile clients expect opaque token + safety profile payload.
    wants_mobile = "newPassword" in request.data or "verificationId" in request.data
    if wants_mobile:
        import uuid

        from apps.mobile_compat.identity import get_or_create_profile
        from apps.mobile_compat.serializers import SafetyProfileSerializer

        profile, _ = get_or_create_profile(email, email=email)
        return Response(
            {
                "token": "token-" + uuid.uuid4().hex[:16],
                "user": SafetyProfileSerializer(profile).data,
                "message": "Password updated. You can sign in now.",
            }
        )
    return Response({"message": "Password updated. You can sign in now."})


@api_view(["POST"])
@permission_classes([permissions.IsAuthenticated])
def change_password(request):
    ser = ChangePasswordSerializer(data=request.data)
    ser.is_valid(raise_exception=True)
    user = request.user
    if not user.check_password(ser.validated_data["current_password"]):
        return Response({"error": "Current password is incorrect."}, status=400)
    user.set_password(ser.validated_data["new_password"])
    user.save()
    AuditService.log(
        actor=user,
        action="user.password_changed",
        object_type="User",
        object_id=str(user.id),
        request=request,
    )
    return Response({"message": "Password updated."})


class UserViewSet(viewsets.ModelViewSet):
    """Platform user management — list/edit/mute/block/delete accounts."""

    search_fields = ["email", "first_name", "last_name", "phone"]
    filterset_fields = ["account_type", "is_active", "is_muted", "email_verified", "is_platform_admin"]
    ordering_fields = ["created_at", "email", "first_name"]
    http_method_names = ["get", "patch", "delete", "post", "head", "options"]

    def get_permissions(self):
        if self.action in ("list", "retrieve", "partial_update", "update", "destroy", "mute", "unmute", "block", "unblock"):
            return [IsAuthenticated(), IsPlatformAdmin()]
        return [IsAuthenticated()]

    def get_serializer_class(self):
        if self.action in ("partial_update", "update"):
            return AdminUserUpdateSerializer
        return UserSerializer

    def get_queryset(self):
        user = self.request.user
        qs = User.objects.all()
        if not user.is_platform_admin:
            qs = qs.filter(id=user.id)

        from apps.safety.models import SafetyProfile

        qs = qs.annotate(
            _bracelet_count=Count("bracelets", distinct=True),
            _owned_people=Count("owned_people", distinct=True),
            _linked_people=Count("person_profiles", distinct=True),
            _has_app_profile=Exists(
                SafetyProfile.objects.filter(user_id=OuterRef("pk"))
            ),
        )

        source = (self.request.query_params.get("source") or "").strip().lower()
        if source == "app":
            qs = qs.filter(_has_app_profile=True)
        elif source == "watch":
            qs = qs.filter(_bracelet_count__gt=0)
        elif source == "org":
            qs = qs.filter(
                Q(account_type="organization") | Q(memberships__is_active=True)
            ).distinct()

        status_filter = (self.request.query_params.get("status") or "").strip().lower()
        if status_filter == "active":
            qs = qs.filter(is_active=True, is_muted=False)
        elif status_filter == "muted":
            qs = qs.filter(is_muted=True, is_active=True)
        elif status_filter == "blocked":
            qs = qs.filter(is_active=False)

        organization = (self.request.query_params.get("organization") or "").strip()
        if organization:
            qs = qs.filter(
                memberships__organization_id=organization,
                memberships__is_active=True,
            ).distinct()

        return qs.order_by("-created_at")

    def perform_update(self, serializer):
        user = serializer.save()
        AuditService.log(
            actor=self.request.user,
            action="user.updated",
            object_type="User",
            object_id=str(user.id),
            metadata={"fields": list(serializer.validated_data.keys())},
        )

    def perform_destroy(self, instance):
        if instance.id == self.request.user.id:
            from rest_framework.exceptions import ValidationError

            raise ValidationError("You cannot delete your own account.")
        if instance.is_platform_admin:
            from rest_framework.exceptions import ValidationError

            raise ValidationError("Cannot delete another platform admin from this screen.")
        user_id = str(instance.id)
        email = instance.email
        instance.delete()
        AuditService.log(
            actor=self.request.user,
            action="user.deleted",
            object_type="User",
            object_id=user_id,
            metadata={"email": email},
        )

    def _set_flag(self, *, muted=None, active=None, action_name: str):
        user = self.get_object()
        if user.id == self.request.user.id and active is False:
            return Response({"error": "You cannot block your own account."}, status=400)
        update_fields = []
        if muted is not None:
            user.is_muted = muted
            update_fields.append("is_muted")
        if active is not None:
            user.is_active = active
            update_fields.append("is_active")
        if update_fields:
            user.save(update_fields=update_fields + ["updated_at"])
        AuditService.log(
            actor=self.request.user,
            action=action_name,
            object_type="User",
            object_id=str(user.id),
            metadata={"is_muted": user.is_muted, "is_active": user.is_active},
        )
        return Response(UserSerializer(user, context={"request": self.request}).data)

    @action(detail=True, methods=["post"])
    def mute(self, request, pk=None):
        return self._set_flag(muted=True, action_name="user.muted")

    @action(detail=True, methods=["post"])
    def unmute(self, request, pk=None):
        return self._set_flag(muted=False, action_name="user.unmuted")

    @action(detail=True, methods=["post"])
    def block(self, request, pk=None):
        return self._set_flag(active=False, action_name="user.blocked")

    @action(detail=True, methods=["post"])
    def unblock(self, request, pk=None):
        return self._set_flag(active=True, action_name="user.unblocked")
