from django.db.models import Q
from rest_framework import viewsets
from rest_framework.exceptions import PermissionDenied, ValidationError

from apps.organizations.permissions import MANAGE_ROLES, get_membership, user_org_ids

from .models import Person, TrustedContact
from .serializers import PersonSerializer, TrustedContactSerializer


class PersonViewSet(viewsets.ModelViewSet):
    serializer_class = PersonSerializer
    search_fields = ["first_name", "last_name", "email", "phone", "external_id"]
    filterset_fields = ["organization", "is_active"]
    ordering_fields = ["first_name", "created_at"]

    def get_queryset(self):
        user = self.request.user
        if user.is_platform_admin:
            return Person.objects.all().select_related("organization")
        org_ids = user_org_ids(user)
        return Person.objects.filter(
            Q(organization_id__in=org_ids) | Q(owner_user=user)
        ).select_related("organization")

    def perform_create(self, serializer):
        user = self.request.user
        org_id = self.request.data.get("organization")
        if org_id:
            if not user.is_platform_admin:
                m = get_membership(user, org_id)
                if not m or m.role not in MANAGE_ROLES:
                    raise PermissionDenied("Cannot create people in this organization.")
            serializer.save(organization_id=org_id)
        else:
            serializer.save(owner_user=user, organization=None)

    def perform_update(self, serializer):
        person = self.get_object()
        self._ensure_write(person)
        serializer.save()

    def perform_destroy(self, instance):
        self._ensure_write(instance)
        instance.delete()

    def _ensure_write(self, person):
        user = self.request.user
        if user.is_platform_admin:
            return
        if person.owner_user_id == user.id:
            return
        if person.organization_id:
            m = get_membership(user, person.organization_id)
            if m and m.role in MANAGE_ROLES:
                return
        raise PermissionDenied()


class TrustedContactViewSet(viewsets.ModelViewSet):
    serializer_class = TrustedContactSerializer
    search_fields = ["name", "email", "phone"]
    filterset_fields = ["organization", "person", "owner_user", "is_active"]

    def get_queryset(self):
        user = self.request.user
        if user.is_platform_admin:
            return TrustedContact.objects.all()
        org_ids = user_org_ids(user)
        return TrustedContact.objects.filter(
            Q(organization_id__in=org_ids) | Q(owner_user=user) | Q(person__owner_user=user)
        )

    def perform_create(self, serializer):
        user = self.request.user
        data = serializer.validated_data
        org = data.get("organization")
        person = data.get("person")
        if org:
            if not user.is_platform_admin:
                m = get_membership(user, org.id)
                if not m or m.role not in MANAGE_ROLES:
                    raise PermissionDenied()
            serializer.save()
        elif person:
            if person.owner_user_id != user.id and not user.is_platform_admin:
                if person.organization_id:
                    m = get_membership(user, person.organization_id)
                    if not m or m.role not in MANAGE_ROLES:
                        raise PermissionDenied()
                else:
                    raise PermissionDenied()
            serializer.save(owner_user=person.owner_user)
        else:
            owner_id = self.request.data.get("owner_user")
            if user.is_platform_admin and owner_id:
                serializer.save(owner_user_id=owner_id)
            else:
                serializer.save(owner_user=user)
